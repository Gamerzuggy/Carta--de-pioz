import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import fs from "fs";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // API endpoint to download the bundled single-file site
  app.get("/api/download-site", (req, res) => {
    const filePath = path.join(process.cwd(), "dist", "index.html");
    
    // Check if the file exists (it should after npm run build)
    if (fs.existsSync(filePath)) {
      res.download(filePath, "alto-de-pioz.html");
    } else {
      res.status(404).send("El archivo no está listo. Por favor, espera a que termine la construcción.");
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
