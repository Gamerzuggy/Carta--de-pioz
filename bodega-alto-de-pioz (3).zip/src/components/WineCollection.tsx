import React from 'react';
import { motion } from 'motion/react';
import LazyImage from './LazyImage';

const products = [
  {
    name: "Alto de Pioz Tinto",
    price: "$719",
    type: "Tinto / Personalidad",
    image: "http://www.bighammerwines.com/cdn/shop/files/2023LaPelleCabernetSauvignonNapaValley.webp?v=1766591943",
    description: "Cata: Rojo picota con ribete granate. Notas de cedro, chocolate fondant y menta. Sabroso y expresivo. 16 meses en barricas de roble francés.",
    allocation: 215
  },
  {
    name: "Las Varas Malvar",
    price: "$800",
    type: "Blanco / Rescate",
    image: "https://www.wineandmore.com/wp-content/uploads/2023/12/The-Best-White-Wine-Glasses-Tested-and-Reviewed-by-Experts-Riedel-Performance-Sauvig-non-Blanc.png",
    description: "Vino elaborado con viña vieja de más de 80 años. Proyecto colaborativo de protección de la D.O. Mondéjar. 92 puntos Gastroactitud.",
    allocation: 142
  },
  {
    name: "Rosado Alto de Pioz",
    price: "$491",
    type: "Rosado / Seducción",
    image: "https://assets.digitalcontent.marksandspencer.app/image/upload/w_2560,q_auto,c_fill,f_auto/ab8f7db0812c39647dfa8887f20cf91d.jpg",
    description: "Cata: Color rojo grosella brillante. Notas exuberantes de frutas rojas ácidas, sandía, granada y yogur de fresa. Amable en boca.",
    allocation: 84
  },
  {
    name: "Sodi de Pioz",
    price: "$1,200",
    type: "Coleccionista",
    image: "https://cdn.galeriemagazine.com/wp-content/uploads/2025/04/PK-23903_web-850x850.jpg?strip=all&quality=92&webp=92&sharp=1",
    description: "Máxima expresión de la viña vieja de Malvar y Tempranillo. 18 meses de crianza en fudres. Un vino de culto diseñado para perdurar.",
    allocation: 12
  },
  {
    name: "Mago de Pioz",
    price: "$650",
    type: "Energía y Fruta",
    image: "https://jbinnacle.com/wp-content/uploads/2025/09/20250823_01_carcavasmingonegro.jpg",
    description: "Rojo picota intenso. Aromas a frutos rojos maduros, notas terrosas, nata y especias. 12 meses en barricas de roble francés.",
    allocation: 48
  }
];

export default function WineCollection() {
  return (
    <section id="collection" className="py-48 px-4 bg-sand">
      <div className="max-w-[1800px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-32 gap-8">
          <div className="text-left">
            <h2 className="text-4xl md:text-7xl text-clay font-serif mb-6">La Colección Privada</h2>
            <p className="text-bronze tracking-widest text-xs uppercase font-medium">Asignaciones exclusivas para México · Cosecha 2024</p>
          </div>
          
          <div className="flex flex-wrap gap-4">
            <a 
              href="/Lista_de_Precios_Alto_De_Pioz_2024.pdf" 
              download
              className="flex items-center gap-3 px-8 py-4 border border-clay text-clay text-[10px] tracking-[0.3em] uppercase hover:bg-clay hover:text-sand transition-all flex-shrink-0 group"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3" />
              </svg>
              Catálogo PDF
            </a>
            <a 
              href="https://wa.me/529544014506" 
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 px-8 py-4 bg-clay text-sand text-[10px] tracking-[0.3em] uppercase hover:bg-gold hover:text-clay transition-all flex-shrink-0 group shadow-2xl relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gold/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
              <svg className="w-4 h-4 relative z-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
              </svg>
              <span className="relative z-10">Acceso a Lista VIP</span>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-px bg-bronze/10">
          {products.map((product, idx) => (
            <WineCard key={idx} product={product} />
          ))}
        </div>

        {/* Portfolio Table - Slide 11 */}
        <div className="mt-48 pt-24 border-t border-bronze/20 max-w-5xl mx-auto overflow-x-auto">
          <h3 className="text-2xl md:text-4xl text-clay font-serif mb-12 text-center uppercase tracking-widest">Portafolio & Maduración</h3>
          <table className="w-full text-left font-sans text-xs md:text-sm">
            <thead>
              <tr className="border-b border-bronze/10 text-bronze uppercase tracking-[0.2em] font-medium">
                <th className="py-6 pb-4">Vino</th>
                <th className="py-6 pb-4">Variedades</th>
                <th className="py-6 pb-4">Crianza</th>
                <th className="py-6 pb-4">Suelo</th>
              </tr>
            </thead>
            <tbody className="text-clay/70">
              <tr className="border-b border-bronze/5">
                <td className="py-6 font-medium text-clay">Alto de Pioz Tinto</td>
                <td className="py-6">Temp/Cab</td>
                <td className="py-6">16 Meses</td>
                <td className="py-6">Arcillo-arenoso</td>
              </tr>
              <tr className="border-b border-bronze/5">
                <td className="py-6 font-medium text-clay">Las Varas Malvar</td>
                <td className="py-6">Malvar (80+ años)</td>
                <td className="py-6">6 Meses</td>
                <td className="py-6">Caliza salpicada</td>
              </tr>
              <tr className="border-b border-bronze/5">
                <td className="py-6 font-medium text-clay">Sodi de Pioz</td>
                <td className="py-6">Tempranillo</td>
                <td className="py-6">18 Meses</td>
                <td className="py-6">Pedregoso pobre</td>
              </tr>
              <tr className="border-b border-bronze/5">
                <td className="py-6 font-medium text-clay">Dominio de Pioz</td>
                <td className="py-6">Temp/Cab</td>
                <td className="py-6">14 Meses</td>
                <td className="py-6">Franco-arcilloso</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function WineCard({ product }: { product: any; key?: any }) {
  return (
    <div className="relative group bg-sand p-12 flex flex-col items-center transition-all duration-700 hover:bg-clay/5 border-b border-bronze/5 md:border-none">
      {/* Allocation Badge - Enhanced Prominence */}
      <div className="absolute top-8 right-8 z-20">
        <div className="flex flex-col items-end">
          <span className="text-[9px] text-bronze uppercase tracking-[0.2em] font-bold mb-2 bg-bronze/5 px-2 py-1">Disponibilidad</span>
          <div className="flex items-center gap-3 bg-clay px-4 py-2 shadow-xl border border-bronze/20">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-base font-mono text-sand leading-none">{product.allocation}</span>
            <span className="text-[10px] font-sans text-sand/40 uppercase tracking-tighter">u.</span>
          </div>
        </div>
      </div>

      <div className="relative h-[450px] md:h-[500px] w-full mb-8 flex justify-center items-center overflow-visible">
        <LazyImage 
          src={product.image} 
          alt={product.name}
          aspectRatio="aspect-square h-full w-auto"
          className="filter drop-shadow-[0_20px_50px_rgba(0,0,0,0.3)] transition-transform duration-700 group-hover:scale-105 group-hover:-rotate-1"
        />
        
        {/* Desktop Hover Overlay - Hidden on Mobile */}
        <div className="hidden md:block absolute inset-x-0 -bottom-12 opacity-0 group-hover:opacity-100 group-hover:bottom-0 transition-all duration-500 bg-sand/95 backdrop-blur-sm p-6 border-t border-bronze/20 z-20">
          <p className="text-xs text-clay italic leading-relaxed">
            {product.description}
          </p>
        </div>
      </div>

      <div className="text-center space-y-3 relative z-10 w-full">
        <p className="text-[10px] tracking-[0.3em] uppercase text-bronze font-medium">
          {product.type}
        </p>
        <h3 className="text-xl md:text-2xl font-serif text-clay group-hover:text-bronze transition-colors">
          {product.name}
        </h3>
        <p className="text-lg font-sans font-light tracking-widest text-clay/40">
          {product.price}
        </p>
        
        {/* Mobile Description - Always Visible below info */}
        <div className="md:hidden pt-4 border-t border-bronze/10 mt-6">
          <p className="text-[11px] text-clay/70 italic leading-relaxed font-light">
            {product.description}
          </p>
        </div>
      </div>

      <a 
        href="https://wa.me/529544014506"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-10 md:opacity-0 md:group-hover:opacity-100 transition-all duration-500 px-10 py-4 bg-clay text-sand text-[10px] tracking-widest uppercase hover:bg-gold hover:text-clay shadow-lg flex items-center gap-3"
      >
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
        </svg>
        Reservar Botella
      </a>
    </div>
  );
}
