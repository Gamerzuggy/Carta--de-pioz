import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function JourneyMap() {
  const svgRef = useRef<SVGSVGElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const pulseRef = useRef<SVGGElement>(null);

  useEffect(() => {
    const path = pathRef.current;
    if (!path || !pulseRef.current) return;

    const length = path.getTotalLength();
    
    // Set initial state
    gsap.set(path, {
      strokeDasharray: length,
      strokeDashoffset: length,
    });

    // Animate the path drawing
    gsap.to(path, {
      strokeDashoffset: 0,
      ease: 'none',
      scrollTrigger: {
        trigger: '#map-section',
        start: 'top center',
        end: 'bottom center',
        scrub: 1,
      },
    });

    // Animate the pulse/jet along the path with scale and glow
    const pulseObj = { distance: 0 };
    gsap.to(pulseObj, {
      distance: length,
      ease: 'none',
      scrollTrigger: {
        trigger: '#map-section',
        start: 'top 40%',
        end: 'bottom 60%',
        scrub: 2,
      },
      onUpdate: () => {
        const point = path.getPointAtLength(pulseObj.distance);
        if (pulseRef.current) {
          // Dynamic scale and glow intensity based on position
          const pulse = Math.sin(Date.now() * 0.005) * 0.2;
          const scale = (1 + pulse) * (1 + Math.sin((pulseObj.distance / length) * Math.PI) * 0.5);
          
          // Rotate based on path tangent
          const nextPoint = path.getPointAtLength(Math.min(length, pulseObj.distance + 1));
          const angle = Math.atan2(nextPoint.y - point.y, nextPoint.x - point.x) * (180 / Math.PI);
          
          pulseRef.current.setAttribute('transform', `translate(${point.x}, ${point.y}) rotate(${angle}) scale(${scale})`);
        }
      }
    });

  }, []);

  return (
    <section id="map-section" className="relative py-48 bg-clay overflow-hidden">
      <div className="max-w-7xl mx-auto px-12 relative z-10">
        <div className="text-center mb-32">
          <h2 className="text-4xl md:text-7xl text-sand font-serif mb-6 uppercase tracking-tight">Métricas del Páramo</h2>
          <p className="text-gold tracking-[0.4em] text-xs uppercase font-light">La ingeniería del terroir indomable</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-48 text-center">
          <div className="space-y-4">
            <h3 className="text-6xl md:text-8xl font-serif text-gold">875m</h3>
            <p className="text-sand/40 tracking-widest uppercase text-xs">Altitud S.N.M.</p>
          </div>
          <div className="space-y-4">
            <h3 className="text-6xl md:text-8xl font-serif text-gold">14ha</h3>
            <p className="text-sand/40 tracking-widest uppercase text-xs">Viñedos Propios</p>
          </div>
          <div className="space-y-4">
            <h3 className="text-6xl md:text-8xl font-serif text-gold">80+</h3>
            <p className="text-sand/40 tracking-widest uppercase text-xs">Años Viñas Viejas</p>
          </div>
        </div>

        <div className="text-center mb-16">
          <h2 className="text-3xl text-sand font-serif mb-4">El Puente Conceptual</h2>
        </div>

        <div className="relative h-[400px] w-full max-w-4xl mx-auto flex justify-between items-center">
          {/* México Point */}
          <div className="flex flex-col items-center">
            <div className="w-5 h-5 rounded-full bg-bronze shadow-[0_0_20px_rgba(198,167,123,0.8)]" />
            <div className="mt-8 text-center">
              <h4 className="text-sand font-serif text-xl">México</h4>
              <p className="text-bronze/60 text-[10px] tracking-widest uppercase font-medium">Corazón Creativo</p>
            </div>
          </div>

          {/* SVG Map Path */}
          <svg 
            ref={svgRef}
            className="absolute top-1/2 left-0 w-full h-[200px] pointer-events-none translate-y-[-50%]"
            viewBox="0 0 800 200"
            fill="none"
          >
            <defs>
              <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>
            {/* Background path faint */}
            <path 
              d="M 20 100 Q 400 -50 780 100" 
              stroke="rgba(198,167,123,0.1)" 
              strokeWidth="1"
              fill="none"
            />
            {/* Animated drawing path */}
            <path 
              ref={pathRef}
              d="M 20 100 Q 400 -50 780 100" 
              stroke="#C6A77B" 
              strokeWidth="2"
              fill="none"
              strokeLinecap="round"
              strokeDasharray="5,5"
            />
          {/* Journey Pulse (The "Jet") */}
          <g ref={pulseRef} style={{ transition: 'transform 0.1s linear' }}>
            <path 
              d="M -10 0 L 10 0 M 0 -10 L 0 10" 
              stroke="#C6A77B" 
              strokeWidth="1"
              opacity="0.3"
            />
            <circle 
              r="4" 
              fill="#C6A77B" 
              filter="url(#glow)"
              className="drop-shadow-[0_0_10px_#C6A77B]"
            />
            <path 
              d="M -8 0 L -20 0" 
              stroke="#C6A77B" 
              strokeWidth="0.5"
              strokeDasharray="2,2"
              opacity="0.5"
            />
          </g>
          </svg>

          {/* Pioz Point */}
          <div className="flex flex-col items-center">
            <div className="w-5 h-5 rounded-full bg-bronze shadow-[0_0_20px_rgba(198,167,123,0.8)]" />
            <div className="mt-8 text-center">
              <h4 className="text-sand font-serif text-xl">España</h4>
              <p className="text-bronze/60 text-[10px] tracking-widest uppercase font-medium">El Terroir</p>
            </div>
          </div>
        </div>

        <div className="mt-48 grid grid-cols-1 md:grid-cols-2 gap-24 text-sand/60 font-sans text-sm leading-relaxed px-12">
          <p>
            Un puente invisible une dos mundos. El carácter indomable del páramo de La Alcarria se encuentra con la pasión creativa de México para dar vida a vinos que son, ante todo, una declaración de principios.
          </p>
          <p>
            Desde la altitud de 875 metros, cada racimo captura el diálogo entre el sol implacable y el frío profundo, traduciendo ese contraste en una elegancia atemporal protegida por manos expertas.
          </p>
        </div>
      </div>
    </section>
  );
}
