import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { gsap } from 'gsap';

export default function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <section 
      ref={containerRef}
      className="relative h-screen w-full flex flex-col justify-center items-center overflow-hidden bg-clay"
    >
      {/* Background Video with refined loading state */}
      <div className="absolute inset-0 z-0 bg-[#1a1a1a]">
        <video 
          autoPlay 
          muted 
          loop 
          playsInline 
          className="w-full h-full object-cover filter saturate-[0.75] brightness-[0.55] animate-slow-zoom"
          src="https://videos.pexels.com/video-files/4763824/4763824-hd_1920_1080_24fps.mp4"
        />
      </div>

      {/* Cinematic Overlays */}
      <div className="absolute inset-0 z-1 bg-radial-[ellipse_at_center,_transparent_30%,_rgba(15,8,5,0.72)_100%] pointer-events-none" />
      <div className="absolute inset-0 z-1 bg-gradient-to-b from-black/25 via-transparent to-black/60 pointer-events-none" />
      <div className="absolute inset-0 z-2 grain opacity-[0.045] pointer-events-none" />
      <div className="absolute inset-0 z-2 scanlines pointer-events-none opacity-[0.08]" />

      {/* Decorative Corners */}
      <div className="absolute top-8 left-8 w-16 h-16 border-t border-l border-bronze/50 z-10 hidden md:block" />
      <div className="absolute bottom-8 right-8 w-16 h-16 border-b border-r border-bronze/50 z-10 hidden md:block" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-6xl">
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="font-montserrat font-extralight text-[clamp(0.6rem,1.1vw,0.8rem)] tracking-[0.45em] uppercase text-gold mb-6"
        >
          Cantabria &nbsp;·&nbsp; España &nbsp;·&nbsp; 875m
        </motion.p>
        
        <motion.span 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 48, opacity: 1 }}
          transition={{ duration: 0.9, delay: 0.7 }}
          className="block w-px bg-gradient-to-b from-transparent via-gold to-transparent mx-auto mb-8"
        />

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 1 }}
          className="font-cormorant font-light text-[clamp(2.5rem,7vw,7.5rem)] leading-[0.95] tracking-tight text-sand mb-8"
        >
          ALTO DE PIOZ <br />
          <em className="italic text-gold text-[0.6em] md:text-[0.5em] block mt-4 font-serif">"El maridaje perfecto entre el vino y el arte"</em>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.4 }}
          className="font-cormorant font-light text-[clamp(0.9rem,1.5vw,1.2rem)] tracking-[0.15em] text-sand/70 max-w-2xl mx-auto leading-relaxed border-t border-gold/20 pt-8 mt-4"
        >
          Ubicada en el pueblo de Pioz, Guadalajara, la bodega está rodeada por un páramo de altitud extrema.
        </motion.p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-12">
          <motion.a 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 1.8 }}
            href="#collection"
            className="inline-flex items-center gap-3 font-montserrat font-light text-xs tracking-[0.3em] uppercase text-sand border-b border-gold/45 pb-2 hover:text-gold hover:border-gold transition-all duration-300 group"
          >
            Explorar Colección
            <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
              <line x1="5" y1="12" x2="19" y2="12"/>
              <polyline points="12 5 19 12 12 19"/>
            </svg>
          </motion.a>

          <motion.a 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 2 }}
            href="https://wa.me/529544014506"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-gold/10 backdrop-blur-md px-8 py-3 rounded-full font-montserrat font-bold text-[10px] tracking-[0.3em] uppercase text-gold hover:bg-gold hover:text-clay transition-all duration-300 shadow-xl border border-gold/20"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
            </svg>
            WhatsApp Concierge
          </motion.a>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 2.4 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="font-montserrat font-extralight text-[0.6rem] tracking-[0.35em] uppercase text-sand/45">Scroll</span>
        <div className="w-[1px] h-10 bg-gradient-to-b from-gold/70 to-transparent relative overflow-hidden">
          <motion.div 
            animate={{ 
              y: [0, 40, 40],
              opacity: [0, 1, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute top-0 left-0 w-full h-full bg-gold"
          />
        </div>
      </motion.div>
    </section>
  );
}
