import { motion } from 'motion/react';
import LazyImage from './LazyImage';

export default function Heritage() {
  const sections = [
    {
      title: "ARQUITECTURA DE CULTO",
      author: "Fase Tadao Ando",
      description: "Casa Primitiva: Concreto, luz y silencio integrados en la naturaleza de La Alcarria. Un santuario de hospitalidad boutique diseñado por el maestro Tadao Ando. Un retiro donde el tiempo se detiene.",
      image: "https://archademia.com/images/blog/Lesson-8_Entrance_Raster-copy-1024x576.jpg",
      layout: "left"
    },
    {
      title: "EL ALMA DE LA MATERIA",
      author: "Bosco Sodi",
      description: "Artista de fama mundial and socio. Diseñador de las etiquetas que capturan la textura y honestidad de la materia prima volcánica y el barro. Cada pieza es una obra visceral que protege el espíritu del terroir.",
      image: "https://cdn.galeriemagazine.com/wp-content/uploads/2025/04/PK-23903_web-850x850.jpg?strip=all&quality=92&webp=92&sharp=1",
      layout: "right"
    },
    {
      title: "EL RIGOR DE LA ÉLITE",
      author: "Rafa Márquez",
      description: "Excelencia deportiva y disciplina. El socio mexicano aporta el rigor de la élite y la mentalidad ganadora a la viticultura de precisión, fusionando el carácter invencible con la elegancia del viejo mundo.",
      image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=1200",
      layout: "left"
    },
    {
      title: "ENOLOGÍA DE PRIMER NIVEL",
      author: "Aurelio García",
      description: "Dirige la producción responsable de vinos premiados, rescatando la biodiversidad de La Alcarria y protegiendo el legado de viñas viejas de más de 80 años en un páramo de altitud extrema.",
      image: "https://images.unsplash.com/photo-1516594915697-87eb3b1c14ea?auto=format&fit=crop&q=80&w=1200",
      layout: "right"
    }
  ];

  return (
    <section id="legacy" className="py-32 px-4 md:px-12 bg-sand overflow-hidden">
      <div className="max-w-7xl mx-auto space-y-48">
        {sections.map((section, idx) => (
          <div 
            key={idx}
            className={`flex flex-col md:flex-row items-center gap-12 md:gap-24 ${
              section.layout === 'right' ? 'md:flex-row-reverse' : ''
            }`}
          >
            <div className="w-full md:w-1/2 overflow-hidden aspect-[4/5] bg-clay/5 group">
              <LazyImage 
                src={section.image} 
                alt={section.title}
                aspectRatio="aspect-full"
                className="transition-transform duration-700 group-hover:scale-105"
              />
            </div>
            
            <div className="w-full md:w-1/2 space-y-8">
              <motion.div
                initial={{ opacity: 0, x: section.layout === 'left' ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, delay: 0.2 }}
              >
                <p className="text-bronze tracking-widest text-xs uppercase mb-4">
                  {section.author}
                </p>
                <h3 className="text-3xl md:text-5xl font-serif text-clay mb-6 leading-tight">
                  {section.title}
                </h3>
                <p className="text-clay/70 font-sans leading-relaxed text-lg max-w-xl">
                  {section.description}
                </p>
              </motion.div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
