import { motion } from 'motion/react';

export default function Footer() {
  return (
    <footer className="bg-clay py-24 px-4 border-t border-bronze/10">
      <div className="max-w-[1800px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16 md:gap-8">
          <div className="md:col-span-2">
            <h3 className="font-cormorant text-sand text-4xl mb-8">Bodega Alto de Pioz</h3>
            <p className="font-montserrat font-extralight text-sand/60 text-sm tracking-widest leading-relaxed max-w-md italic">
              "El vino es la única obra de arte que se puede beber". Hecho con manos que aman la tierra española y disfrutado con el alma indomable de México. Una herencia que no se compra, se merece.
            </p>
          </div>
          
          <div>
            <h4 className="text-gold text-[10px] tracking-[0.4em] uppercase mb-8">Contacto</h4>
            <ul className="space-y-4 font-montserrat font-light text-sand/80 text-xs">
              <li>Pioz, Guadalajara, España</li>
              <li>info@altodepioz.com</li>
              <li>+34 949 272 XXX</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-gold text-[10px] tracking-[0.4em] uppercase mb-8">Suscripción</h4>
            <div className="border-b border-bronze/30 pb-2 flex items-center justify-between">
              <input 
                type="email" 
                placeholder="TU EMAIL" 
                className="bg-transparent text-sand text-[10px] tracking-widest outline-none w-full"
              />
              <button className="text-gold hover:text-sand transition-colors">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                  <line x1="5" y1="12" x2="19" y2="12"/>
                  <polyline points="12 5 19 12 12 19"/>
                </svg>
              </button>
            </div>
            <p className="mt-4 text-[9px] text-sand/40 tracking-widest uppercase">Únete a la asignación privada</p>
          </div>
        </div>
        
        <div className="mt-32 pt-8 border-t border-bronze/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[9px] text-sand/30 tracking-[0.3em] uppercase">© 2024 Alto de Pioz. Legado de Culto.</p>
          <div className="flex gap-8">
            <a href="#" className="text-[9px] text-sand/30 tracking-[0.3em] uppercase hover:text-gold transition-colors">Aviso Legal</a>
            <a href="#" className="text-[9px] text-sand/30 tracking-[0.3em] uppercase hover:text-gold transition-colors">Instagram</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
