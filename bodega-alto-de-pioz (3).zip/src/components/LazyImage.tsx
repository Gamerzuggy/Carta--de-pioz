import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface LazyImageProps {
  src: string;
  alt: string;
  className?: string;
  aspectRatio?: string;
}

export default function LazyImage({ src, alt, className = "", aspectRatio = "aspect-[3/4]" }: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = src;
    img.onload = () => setIsLoaded(true);
    img.onerror = () => setError(true);
  }, [src]);

  return (
    <div className={`relative overflow-hidden bg-bronze/5 ${aspectRatio} ${className}`}>
      {/* Skeleton / LQIP Placeholder */}
      <AnimatePresence>
        {!isLoaded && !error && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0 z-10 flex items-center justify-center bg-sand-dark/20 backdrop-blur-sm"
          >
            <div className="w-12 h-12 border-t-2 border-bronze/20 rounded-full animate-spin" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Actual Image */}
      <motion.img
        src={src}
        alt={alt}
        initial={{ opacity: 0, scale: 1.05 }}
        animate={{ 
          opacity: isLoaded ? 1 : 0,
          scale: isLoaded ? 1 : 1.05
        }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className={`w-full h-full object-cover transition-all duration-700 ${isLoaded ? 'blur-0' : 'blur-xl'}`}
      />

      {/* Error Fallback */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-sand-dark/10 p-4 text-center">
          <span className="text-[10px] uppercase tracking-widest text-clay/40 font-light">
            Imagen no disponible
          </span>
        </div>
      )}
    </div>
  );
}
